$( document ).ready(function() {
  $("body").click(function(){
    //Realiza las selecciones en este bloque de código


    
  });
});
