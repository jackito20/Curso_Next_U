import { Component, OnInit } from '@angular/core';
import { NgDatepickerModule } from 'ng2-datepicker';

@Component({
  selector: 't-nueva-tarea',
  templateUrl: './nueva-tarea.component.html',
  styleUrls: ['./nueva-tarea.component.css']
})
export class NuevaTareaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
